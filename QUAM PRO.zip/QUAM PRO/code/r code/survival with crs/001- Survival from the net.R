getwd()


library(survival)
library(foreign)
library(rms)
library(ROCR)
library(DMwR2)
library(cluster)
library(riskRegression)
library(caret)
library(parallel)
library(cmprsk)
library(aod)
library(pec)
library(gbm)
library(boot)
library(prodlim)


options(scipen=200)
options(rf.cores = -1)


################################### No.1  Fine-Gray competing risks #################################
data("Melanoma")
str(Melanoma)

attach(Melanoma)
names(Melanoma)

cif <- cuminc(ftime = time, fstatus = status, group = ulcer)
plot(cif, col = 1:4, xlabs = "Days")

cif$Tests

csh <- coxph(Surv(time, status == 1) ~ sex + age + invasion 
             + ici + epicel + ulcer + thick, 
             data = Melanoma)
summary(csh)

##################   Models   ############################

csh <- CSC(Hist(time, status) ~ sex + age + invasion 
           + ici + epicel + ulcer + thick, 
           data = Melanoma)
csh


model <- FGR(Hist(time, status) ~ sex + age + invasion 
             + ici + epicel + ulcer + thick,
             data = Melanoma, cause = 1)
model


cindex.pec  <- pec::cindex(csh,
                            formula = Hist(time, status) ~ sex + age + invasion 
                            + ici + epicel + ulcer + thick,
                            data = Melanoma,
                            cens.model = "marginal", 
                            cause = 1, eval.times = 10)


cindex.Melanoma <- cindex.pec$AppCindex$FGR
cindex.Melanoma


#' 		  data=dat,
#' 		  eval.times=seq(1,15,1)  