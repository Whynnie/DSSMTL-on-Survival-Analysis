setwd("C:/Users/USR/Documents/External Projects/MSc Survival analysis with deep learning/Survival analysis without CR/")
rm(list=ls())

library(survival)
library(foreign)
library(rms)
library(ROCR)
library(caret)
library(cluster)
library(randomForestSRC)
library(parallel)
library(cmprsk)
library(aod)
library(pec)
library(gbm)
library(ranger)
library(boot)
options(scipen=200)
options(contrasts=c("contr.treatment", "contr.treatment"))


# ******************************************** seer *************************************************
#####################################################################################################
########################################### load data ###############################################
#####################################################################################################

train <- read.csv("colon_deaths_train.csv")
test <- read.csv("colon_deaths_test.csv")
str(train)

sum(is.na(test))

colnames(train)[colnames(train) == "status"] <- "os"
colnames(test)[colnames(test) == "status"] <- "os"

# -------------------------------------------------------------------------------------------
##################################### No.1 Cox survival #####################################
# -------------------------------------------------------------------------------------------

###################################### modeling ##################################
model <- coxph(Surv(time, os) ~ age + sex + obstruct + perfor + adhere
               + nodes + differ + extent + surg + node4,
               data = train, x = TRUE)


####################################### cindex ###################################
concordance(model)
concordance(model, newdata = test)



####################################### ibs ###################################
# Using pec for IBS estimation
ibs.train <- pec(object = model,
                 formula = Surv(time, os) ~ age + sex + obstruct + perfor + adhere
                 + nodes + differ + extent + surg + node4,
                 cens.model = "marginal", times = c(12,24,36,48,60,72,84,96), exact = TRUE,
                 data = train, verbose = F, maxtime = 1000)
ibs.train.v <- crps(ibs.train)[2]
ibs.train.v


ibs.test <- pec(object = model,
                formula = Surv(time, os) ~ age + sex + obstruct + perfor + adhere
                + nodes + differ + extent + surg + node4,
                cens.model = "marginal", times = c(12,24,36,48,60,72,84,96), exact = TRUE,
                data = test, verbose = F, maxtime = 1000)
ibs.test.v <- crps(ibs.test)[2]
ibs.test.v


####################################### bootstrap ###################################
Beta.model <- function(data, indices){
  d <- data[indices,]
  model <- coxph(Surv(time, os) ~ age + sex + obstruct + perfor + adhere
                 + nodes + differ + extent + surg + node4,
                 data = d,
                 x = TRUE)
  cindex.train <- concordance(model)$concordance
  
  cindex.test <- concordance(model, newdata = test)$concordance
  
  
  ibs.train <- pec(object = model,
                   formula = Surv(time, os) ~ age + sex + obstruct + perfor + adhere
                   + nodes + differ + extent + surg + node4,
                   cens.model = "marginal", times = c(12,24,36,48,60,72,84,96), exact = TRUE,
                   data = d,
                   verbose = F, maxtime = 200)
  ibs.train.v <- crps(ibs.train)[2]
  
  
  ibs.test <- pec(object = model,
                  formula = Surv(time, os) ~ age + sex + obstruct + perfor + adhere
                  + nodes + differ + extent + surg + node4,
                  cens.model = "marginal", times = c(12,24,36,48,60,72,84,96), exact = TRUE,
                  data = test, verbose = F, maxtime = 200)
  ibs.test.v <- crps(ibs.test)[2]
  
  return(c(cindex.train, cindex.test, ibs.train.v, ibs.test.v))
}

result.ci <- boot(data = train, statistic = Beta.model, R = 100)
save(result.ci, file = "result.colon.ci.cox.R")
load(file = "result.colon.ci.cox.R")


round(mean(result.ci$t[, 1]), 4)
round(mean(result.ci$t[, 2]), 4)
round(mean(result.ci$t[, 3]), 4)
round(mean(result.ci$t[, 4]), 4)


get_cis <- function(idx){
  boots.train.cindex.rsf <- result.ci
  boots.train.cindex.rsf$t0 <- result.ci$t0[idx]
  boots.train.cindex.rsf$t <- as.matrix(result.ci$t[, idx])
  res <- boot.ci(boots.train.cindex.rsf, conf = 0.95, type = "perc")
  return(res$percent[4:5])
}
# train cindex
round(get_cis(1), 4)

# test cindex
round(get_cis(2), 4)


# train ibs
round(get_cis(3), 4)

# test ibs
round(get_cis(4), 4)

